<?php

define('DBHOST', 'localhost');
define('DBNAME', 'student registration');
define('DBUSER', 'root');
define('DBPASS', '');

?>